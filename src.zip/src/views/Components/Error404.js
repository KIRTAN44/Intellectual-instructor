import React from 'react';
import image from "assets/img/404.png";
import { Link, useHistory } from "react-router-dom";

export default function Error404() {
    return (
        <div>
            {/* <h1>Hmmm... can't seem to find that page.</h1>
            <Link to="/videos"><img>Take me home</img></Link> */}
        </div>
    )
}
